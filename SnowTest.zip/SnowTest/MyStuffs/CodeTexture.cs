﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CodeTexture : MonoBehaviour
{
    Texture2D m_texture;
    public Transform max_y;
    public Texture2D m_bump; 
    Texture2D m_show_error;
    RenderTexture test_render;
    Color[] sample_area;
    Color[] bump_sample_area;
    Color[] compare_area;
    Color[] brush_area;
    Color[] brush_bump_area;
    public Renderer snow_mesh;

    public int hole_size = 32;
    public int bump_size=4;
    public int hole_half_size;
    public int bump_dia;
    public int bump_half_dia;

    public float max_depth = 0;

	// Use this for initialization
	void Start ()
    {
        hole_half_size = hole_size/2;
        bump_dia = 2*bump_size + hole_size;
        bump_half_dia = bump_dia / 2;

        max_depth = transform.position.y - max_y.position.y;

        sample_area = new Color[hole_size * hole_size];
        brush_area = new Color[hole_size*hole_size];
        brush_bump_area = new Color[bump_dia*bump_dia];

        m_texture = new Texture2D(1024,1024);
        m_texture.SetPixels(0,0,1024,1024,new Color[1024*1024]);
        m_texture.Apply();
        snow_mesh.material.SetTexture("_SnowTrackTex", m_texture);

        test_render = new RenderTexture(1024,1024,32);
        //snow_mesh.material.SetTexture("_SnowTrackTex", test_render);

        m_bump = new Texture2D(1024, 1024);
        m_bump.SetPixels(0, 0, 1024, 1024, new Color[1024 * 1024]);
        m_bump.Apply();
        snow_mesh.material.SetTexture("_BumpTrackTex", m_bump);


        //预设深坑图形
        float val, sqr;
        for (int i = 0; i < hole_size; i++)
        {
            for(int j = 0; j < hole_size; j++)
            {
                sqr = Mathf.Pow(hole_half_size- i, 2) + Mathf.Pow(hole_half_size - j, 2);
                val = 1-sqr / (hole_half_size * hole_half_size);
                val = Mathf.Clamp(val,0.0f,1.0f);
                sample_area[i * hole_size + j] = val*Color.white;
            }
        }

        bump_sample_area= new Color[bump_dia * bump_dia];
        for (int i = 0; i < bump_dia; i++)
        {
            for (int j = 0; j < bump_dia; j++)
            {
                sqr = Mathf.Pow(bump_half_dia - i, 2) + Mathf.Pow(bump_half_dia - j, 2);
                //Cut the center and the out area
                if (Mathf.Sqrt(sqr) > hole_half_size&&Mathf.Sqrt(sqr) < bump_half_dia)
                {
                    sqr = Mathf.Abs(Mathf.Sqrt(sqr) - (bump_half_dia + hole_half_size) / 2);

                    val = 1 - Mathf.Pow(sqr / (bump_size/2),2);
                    val = Mathf.Clamp(val, 0.0f, 1.0f);
                    bump_sample_area[i * bump_dia + j] = val * Color.white;
                }
            }
        }

    }
	
	// Update is called once per frame
	void Update ()
    {

    }

    public void DrawHoleAtPoint(int x, int y,float posy)
    {
        int realx, realy;
        float depth=(transform.position.y-posy)/max_depth;
        depth = Mathf.Clamp(depth,0.0f,1.0f);
        depth = Mathf.Sqrt(depth);
        realx = Mathf.Clamp(x - hole_half_size, 0, 1024);
        realy = Mathf.Clamp(y - hole_half_size, 0, 1024);

        for (int i = 0; i < sample_area.Length; i++)
        {
            brush_area[i] = sample_area[i];
        }

        compare_area = m_texture.GetPixels(realx, realy, hole_size, hole_size);

        for (int i = 0; i < compare_area.Length; i++)
        {
            if (compare_area[i].r > brush_area[i].r)
            {
                brush_area[i].r = compare_area[i].r;
            }
            if (brush_area[i].r>0.0f)
            {
                brush_area[i].g = depth;
                if(compare_area[i].g > brush_area[i].g)
                {
                    brush_area[i].g = compare_area[i].g;
                }
            }
        }

        m_texture.SetPixels(realx, realy, hole_size, hole_size, brush_area);
        m_texture.Apply();
        DrawBumpAt(x,y,depth);
    }

    void DrawBumpAt(int x, int y,float depth)
    {
        int realx, realy;
        realx = x- bump_half_dia;
        realy = y- bump_half_dia;
        if (x < 0 || y < 0||x>1024||y>1024)
            return;
        for(int i = 0; i < bump_sample_area.Length; i++)
        {
            brush_bump_area[i] = bump_sample_area[i];
        }

        compare_area = m_bump.GetPixels(realx, realy, bump_dia, bump_dia);

        for (int i = 0; i < compare_area.Length; i++)
        {
            if (compare_area[i].r > brush_bump_area[i].r)
            {
                brush_bump_area[i].r = compare_area[i].r;
            }
        }

        compare_area = m_texture.GetPixels(realx, realy, bump_dia, bump_dia);

        for (int i = 0; i < compare_area.Length; i++)
        {
            if (compare_area[i].r > 0.0f)
            {
                brush_bump_area[i].r = 0.0f;
            }
        }

        compare_area = m_bump.GetPixels(realx, realy, bump_dia, bump_dia);

        for (int i = 0; i < compare_area.Length; i++)
        {
            if (bump_sample_area[i].r>0.0f)
            {
                brush_bump_area[i].g = depth;
            }
            if (compare_area[i].g > brush_bump_area[i].g)
            {
                brush_bump_area[i].g = compare_area[i].g;
            }
        }

        m_bump.SetPixels(realx, realy, bump_dia, bump_dia, brush_bump_area);
        m_bump.Apply();
    }

    void DrawRender(Texture2D brush)
    {
        RenderTexture.active = test_render;                      //Set my RenderTexture active so DrawTexture will draw to it.
        GL.PushMatrix();                    //Saves both projection and modelview matrices to the matrix stack.
        GL.LoadPixelMatrix(0, 640, 480, 0);       //Setup a matrix for pixel-correct rendering.
        //Draw my stampTexture on my RenderTexture positioned by posX and posY.
        GL.PopMatrix();                    //Restores both projection and modelview matrices off the top of the matrix stack.
        RenderTexture.active = test_render;
    }
}
