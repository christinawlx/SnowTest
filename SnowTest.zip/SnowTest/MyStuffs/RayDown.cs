﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RayDown : MonoBehaviour
{
    CodeTexture tex;
	// Use this for initialization
	void Start ()
    {
        tex = FindObjectOfType<CodeTexture>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position, Vector3.down,out hit))
        {
            Vector2 uv = hit.textureCoord;
            int mx = (int)(uv.x*1024);
            int my = (int)(uv.y*1024);
            tex.DrawHoleAtPoint(mx,my,transform.position.y);
        }
	}
}
